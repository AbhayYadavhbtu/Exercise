import { AfterViewInit, Component } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from '../app.component';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-homepage',
  standalone: true,
  imports:[RouterModule,CommonModule],
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  host: { 'ngSkipHydration': '' }
})
export class HomepageComponent implements AfterViewInit {
  

  ngAfterViewInit() {
    const list: NodeListOf<HTMLLIElement> = document.querySelectorAll(".navigation li");

    function activeLink(this: HTMLLIElement): void {
      list.forEach((item) => {
        item.classList.remove("hovered");
      });
      this.classList.add("hovered");
    }

    list.forEach((item) => item.addEventListener("mouseover", activeLink));
    
    const toggle = document.querySelector('.toggle') as HTMLElement;
    const navigation = document.querySelector('.navigation') as HTMLElement;
    const main = document.querySelector('.main') as HTMLElement;

    if (toggle && navigation && main) {
      toggle.onclick = () => {
        navigation.classList.toggle('active');
        main.classList.toggle('active');
      };
    }
  }

 
}
