import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

import { QuoteFormComponent } from './quote/quote-form/quote-form.component';
import { QuoteResultComponent } from './quote/quote-result/quote-result.component';
import { QuoteListComponent } from './quote/quote-list/quote-list.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactComponent } from './components/contact/contact.component';
import { MainpageComponent } from './components/mainpage/mainpage.component';
import { ClientManagementComponent } from './components/client-management/client-management.component';


export const routes: Routes = [
  { path: '', redirectTo: 'main', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomepageComponent },
  { path: 'quote', component: QuoteFormComponent },
  { path: 'quote-result', component: QuoteResultComponent },
  { path: 'quote-list', component: QuoteListComponent },
  { path: 'contact', component: ContactComponent},
  { path: 'main', component: MainpageComponent},
  { path: 'client', component: ClientManagementComponent},
  { path: '**', redirectTo: 'login' }
];
