import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  // Dropdown state
  dropdowns = {
    resources: false,
    about: false
  };

  onLogin() {
    console.log('Login Clicked:', this.username, this.password);
  }

  toggleDropdown(menu: 'resources' | 'about', event: Event) {
    event.preventDefault();
    this.dropdowns[menu] = !this.dropdowns[menu];

    // Close other dropdowns
    Object.keys(this.dropdowns).forEach(key => {
      if (key !== menu) {
        this.dropdowns[key as 'resources' | 'about'] = false;
      }
    });
  }
}
