import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuoteService } from '../quote.service';

@Component({
  selector: 'app-quote-result',
  templateUrl: './quote-result.component.html',
  styleUrls: ['./quote-result.component.css']
})
export class QuoteResultComponent implements OnInit {
  quoteResult: any;

  constructor(private router: Router, private quoteService: QuoteService) {}

  ngOnInit(): void {
    this.quoteResult = this.quoteService.getQuoteResult();
    if (!this.quoteResult) {
      // If no quote data exists, navigate back to the quote form.
      this.router.navigate(['/quote']);
    }
  }

  editQuote() {
    this.router.navigate(['/quote']);
  }

  bindQuote() {
    alert('Quote has been bound!');
  }

  deleteQuote() {
    alert('Quote has been deleted!');
    this.quoteService.clearQuoteResult();
    this.router.navigate(['/quote']);
  }
}
