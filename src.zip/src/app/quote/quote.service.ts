// src/app/quote/quote.service.ts
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private quoteResult: any;

  constructor() { }

  calculatePremium(quoteData: any): Observable<number> {
    // Simulate a backend call – in a real application, replace this with an HTTP request.
    const dummyPremium = 1234.56;
    return of(dummyPremium).pipe(delay(1000)); // simulate a 1-second delay
  }

  setQuoteResult(data: any) {
    this.quoteResult = data;
  }

  getQuoteResult() {
    return this.quoteResult;
  }

  clearQuoteResult() {
    this.quoteResult = null;
  }
}
