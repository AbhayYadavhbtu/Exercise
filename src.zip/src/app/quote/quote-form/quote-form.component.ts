import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate } from '@angular/animations';

@Component({
  selector: 'app-quote-form',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './quote-form.component.html',
  styleUrls: ['./quote-form.component.css'],
  animations: [
    trigger('slideAnimation', [
      // When new content enters:
      transition(':enter', [
        style({ opacity: 0, transform: 'translateX({{enter}})' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateX(0)' }))
      ], { params: { enter: '100%' } }),
      // When current content leaves:
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'translateX({{leave}})' }))
      ], { params: { leave: '-100%' } })
    ])
  ]
})
export class QuoteFormComponent implements OnInit {
  currentStep = 1;
  quoteForm!: FormGroup;

  // Animation parameters
  slideEnter: string = '100%';
  slideLeave: string = '-100%';

  // Autocomplete data for Business Location (Step 2)
  ZIP_CODES: string[] = [
    '70001', '70002', '70003', '70004', '70005', '70006', '70007', '70008', '70009', '70010',
    '70011', '70012', '70013', '70014', '70015', '70016', '70017', '70018', '70019', '70020',
    '70021', '70022', '70023', '70024', '70025', '70026', '70027', '70028', '70029', '70030',
    '70031', '70032', '70033', '70034', '70035', '70036', '70037', '70038', '70039', '70040',
    '70041', '70042', '70043', '70044', '70045', '70046', '70047', '70048', '70049', '70050'
  ];

  // Home Type options for Step 3
  homeOptions = [
    { type: 'Single-Family', label: 'Single Family', icon: 'images/SingleHome.svg' },
    { type: '2-4 Family Building', label: '2-4 Family', icon: 'images/2-4.svg' },
    { type: 'Mobile Home / Manufactured', label: 'Mobile/Manufactured Home', icon: 'images/Manufactured.svg' },
    { type: 'Residential Condo Building', label: 'Condo Building', icon: 'images/Condo.svg' },
    { type: 'Commercial', label: 'Commercial Unit', icon: 'images/Commercial.svg' },
    { type: 'Other Residential', label: 'Other Residential', icon: 'images/others.svg' },
  ];

  foundationOptions = [
    { type: 'Slab-On-Grade', label: 'Single Family', icon: 'images/Slab.svg' },
    { type: 'Basement', label: '2-4 Family', icon: 'images/Basement.svg' },
    { type: 'Crawlspace', label: 'Mobile/Manufactured Home', icon: 'images/CrawlSpace.svg' },
    { type: 'Elevated (Enclosure on Posts/Piles)', label: 'Condo Building', icon: 'images/garage.svg' },
    { type: 'Elevated (Open Posts/Piles)', label: 'Commercial Unit', icon: 'images/Stilts and Pilings.svg' },
   
  ];


  filteredLocations: string[] = [];
  showSuggestions: boolean = false;

   // Construction Type & Number of Stories (Step 5 – “Property Information”)
   constructionTypes = [
    { value: 'Wood Frame', label: 'Wood Frame' },
    { value: 'SteelFrame', label: 'Steel Frame' },
    { value: 'Concrete', label: 'Concrete' },
    { value: 'Masonry', label: 'Masonry / Bricks' }
  ];
  storiesOptions = [
    { value: '1', label: 'One Story' },
    { value: '2', label: 'Two Story' },
    { value: '3', label: 'Three Story' },
    { value: '4', label: 'Three Story or more' }
  ];

  floorHeights: string[] = ['1','2','3','4','5','6','7','8', '9', '10', '11', '12'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.quoteForm = this.fb.group({
      // Step 1: Basic Information
      customerName: ['', Validators.required],
      customerEmail: ['', [Validators.required, Validators.email]],
      customerContact: ['', Validators.required],
      // Step 2: Business Location
      businessLocation: ['', Validators.required],
      // Step 3: Home Type
      homeType: ['', Validators.required],
       // Step 4: Foundation Type
       foundationType: ['', Validators.required],
       


      
      // Step 5 (Property Info)
      yearBuilt: ['', Validators.required],
      squareFeet: ['', Validators.required],
      constructionType: ['', Validators.required],
      numberOfStories: ['', Validators.required],
      firstFloorHeight: ['', Validators.required],
      basement: [false],

      /* CHANGED: Step 6 form controls – coverage form. */
      buildingCoverage: ['', Validators.required],
      personalProperty: ['', Validators.required],
      deductible: ['', Validators.required] 

      // (Add additional controls as needed)
    });

    // Filter zip codes as the user types in businessLocation
    this.quoteForm.get('businessLocation')?.valueChanges.subscribe(val => {
      this.filterLocations(val);
    });
  }

  // Helper method to extract input value from event
  getInputValue(event: any): string {
    return event.target.value;
  }

  filterLocations(val: string) {
    if (!val) {
      this.filteredLocations = [];
      this.showSuggestions = false;
    } else {
      this.filteredLocations = this.ZIP_CODES.filter(zip =>
        zip.toLowerCase().includes(val.toLowerCase())
      );
      this.showSuggestions = this.filteredLocations.length > 0;
    }
  }

  selectLocation(suggestion: string) {
    this.quoteForm.get('businessLocation')?.setValue(suggestion);
    this.showSuggestions = false;
  }

  hideSuggestions() {
    setTimeout(() => { this.showSuggestions = false; }, 200);
  }

  // When user clicks on a home type card
  selectHomeType(home: string) {
    this.quoteForm.get('homeType')?.setValue(home);
  }
  // When user clicks on a home type card
  selectFoundationType(foundation: string) {
    this.quoteForm.get('foundationType')?.setValue(foundation);
  }

  selectConstructionType(ctype: string) {
    this.quoteForm.get('constructionType')?.setValue(ctype);
  }
  selectNumberOfStories(story: string) {
    this.quoteForm.get('numberOfStories')?.setValue(story);
  }

  isInvalid(controlName: string): boolean {
    const control = this.quoteForm.get(controlName);
    return control ? control.invalid && (control.dirty || control.touched) : false;
  }

  nextStep() {
    // Set slide animation parameters for "Next"
    this.slideEnter = '100%';
    this.slideLeave = '-100%';
    if (this.currentStep < 7) {
      this.currentStep++;
    }
  }

  previousStep() {
    // Set slide animation parameters for "Back"
    this.slideEnter = '-100%';
    this.slideLeave = '100%';
    if (this.currentStep > 1) {
      this.currentStep--;
    }
  }

  submitQuote() {
    if (this.quoteForm.valid) {
      console.log('Quote Submitted', this.quoteForm.value);
      alert('Quote submitted successfully!');
    } else {
      alert('Please fill out all required fields.');
    }
  }
}
