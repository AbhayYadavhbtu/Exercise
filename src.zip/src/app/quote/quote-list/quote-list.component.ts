import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Core Quote interface (without status and createdDate)
interface Quote {
  id: number;
  customerName: string;
  customerEmail: string;
  premium: number;
  // Additional fields for the modal
  customerContact: string;
  businessLocation: string;
  homeType: string;
  foundationType: string;
  yearBuilt: string;
  squareFeet: string;
  constructionType: string;
  numberOfStories: string;
  firstFloorHeight: string;
  basement: boolean;
  buildingCoverage: string;
  personalProperty: string;
  deductible: string;
}

@Component({
  selector: 'app-quote-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './quote-list.component.html',
  styleUrls: ['./quote-list.component.css']
})
export class QuoteListComponent implements OnInit {
  // Hardcoded quotes array with status and createdDate defined explicitly.
  // We use an intersection type: Quote & { status: string, createdDate: string }
  // Using current date for createdDate
  allQuotes: (Quote & { status: string; createdDate: string })[] = [
    {
      id: 1,
      customerName: 'Alice Johnson',
      customerEmail: 'alice@example.com',
      premium: 480.5,
      customerContact: '1234567890',
      businessLocation: '70001',
      homeType: 'Single-Family',
      foundationType: 'Slab-On-Grade',
      yearBuilt: '2005',
      squareFeet: '1500',
      constructionType: 'Wood Frame',
      numberOfStories: '1',
      firstFloorHeight: '10',
      basement: false,
      buildingCoverage: '250000',
      personalProperty: '25000',
      deductible: '1000',
      // Created date set to current date
      status: 'Pending',
      createdDate: new Date().toLocaleDateString()
    },
    {
      id: 2,
      customerName: 'Bob Smith',
      customerEmail: 'bob@example.com',
      premium: 530.2,
      customerContact: '9876543210',
      businessLocation: '70002',
      homeType: 'Mobile Home / Manufactured',
      foundationType: 'Crawlspace',
      yearBuilt: '2010',
      squareFeet: '1200',
      constructionType: 'Steel Frame',
      numberOfStories: '1',
      firstFloorHeight: '9',
      basement: false,
      buildingCoverage: '200000',
      personalProperty: '15000',
      deductible: '2000',
      status: 'Pending',
      createdDate: new Date().toLocaleDateString()
    },
    {
      id: 3,
      customerName: 'Charlie Davis',
      customerEmail: 'charlie@example.com',
      premium: 610.75,
      customerContact: '5551112222',
      businessLocation: '70003',
      homeType: '2-4 Family Building',
      foundationType: 'Basement',
      yearBuilt: '1998',
      squareFeet: '3000',
      constructionType: 'Concrete',
      numberOfStories: '2',
      firstFloorHeight: '11',
      basement: true,
      buildingCoverage: '300000',
      personalProperty: '30000',
      deductible: '5000',
      status: 'Pending',
      createdDate: new Date().toLocaleDateString()
    },
    {
      id: 4,
      customerName: 'Diana West',
      customerEmail: 'diana@example.com',
      premium: 455.1,
      customerContact: '3334445555',
      businessLocation: '70004',
      homeType: 'Condo Building',
      foundationType: 'Slab-On-Grade',
      yearBuilt: '2000',
      squareFeet: '900',
      constructionType: 'Masonry',
      numberOfStories: '3',
      firstFloorHeight: '12',
      basement: false,
      buildingCoverage: '180000',
      personalProperty: '10000',
      deductible: '2000',
      status: 'Pending',
      createdDate: new Date().toLocaleDateString()
    }
  ];

  // Filtered array used in the table
  filteredQuotes: (Quote & { status: string; createdDate: string })[] = [];

  // For search and status filter
  searchName: string = '';
  selectedStatus: string = '';

  // For the modal popup
  selectedQuote: (Quote & { status: string; createdDate: string }) | null = null;

  ngOnInit(): void {
    // Initially display all quotes
    this.filteredQuotes = [...this.allQuotes];
  }

  // Called when user types in search or changes status
  filterQuotes(): void {
    this.filteredQuotes = this.allQuotes.filter(q => {
      const matchesName = q.customerName.toLowerCase().includes(this.searchName.toLowerCase());
      const matchesStatus = this.selectedStatus ? q.status.toLowerCase() === this.selectedStatus.toLowerCase() : true;
      return matchesName && matchesStatus;
    });
  }

  // Called when user clicks "View" (opens modal)
  viewQuote(quote: (Quote & { status: string; createdDate: string })): void {
    this.selectedQuote = quote;
  }

  // Called when user clicks outside the modal or on close button
  closeModal(): void {
    this.selectedQuote = null;
  }

  // Called when user clicks "Edit"
  editQuote(quote: (Quote & { status: string; createdDate: string })): void {
    alert(`Edit quote for ${quote.customerName}`);
  }

  // Called when user clicks "Delete"
  deleteQuote(quote: (Quote & { status: string; createdDate: string })): void {
    if (confirm(`Are you sure you want to delete the quote for ${quote.customerName}?`)) {
      this.allQuotes = this.allQuotes.filter(q => q.id !== quote.id);
      this.filterQuotes();
      if (this.selectedQuote && this.selectedQuote.id === quote.id) {
        this.selectedQuote = null;
      }
    }
  }

  // Called when user clicks "Submit for Bind"
  bindQuote(quote: (Quote & { status: string; createdDate: string })): void {
    if (quote.status.toLowerCase() === 'pending') {
      quote.status = 'Bind requested';
      alert(`Bind requested for ${quote.customerName}`);
    } else {
      alert(`Quote status is "${quote.status}". Only "Pending" quotes can be bound.`);
    }
  }

  // Map status to CSS badge classes
  statusBadgeClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'pending-badge';
      case 'bind requested':
        return 'draft-badge';
      case 'rejected':
        return 'rejected-badge';
      default:
        return 'draft-badge';
    }
  }
}
