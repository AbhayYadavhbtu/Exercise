import {
  Component,
  OnInit,
  AfterViewInit,
  Renderer2,
  Inject,
  HostListener,
  ViewEncapsulation
} from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { BrokerRegistrationComponent } from '../broker-registration/broker-registration.component';
import { FormsModule } from '@angular/forms';

declare var feather: any;

@Component({
  selector: 'app-mainpage',
  imports:[BrokerRegistrationComponent,CommonModule,FormsModule],
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MainpageComponent implements OnInit, AfterViewInit {
  scrolled = false;
  showRegistration = false;

  

  constructor(
    private renderer: Renderer2,
    @Inject(DOCUMENT) private document: Document
  ) {}

  ngOnInit(): void {
    const tailwindScript = this.renderer.createElement('script');
    tailwindScript.src = 'https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4';
    tailwindScript.async = true;
    this.renderer.appendChild(this.document.head, tailwindScript);
  }

  ngAfterViewInit(): void {
    if (feather) feather.replace();
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollY =
      window.pageYOffset ||
      this.document.documentElement.scrollTop ||
      this.document.body.scrollTop ||
      0;
    this.scrolled = scrollY > 50;
  }

  openRegistration() {
    this.showRegistration = true;
    console.log("true");
  }

  closeRegistration() {
    this.showRegistration = false;
  }
}
