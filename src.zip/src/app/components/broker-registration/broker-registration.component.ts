import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-broker-registration',
  standalone:true,
  imports:[FormsModule,CommonModule,ReactiveFormsModule],
  templateUrl: './broker-registration.component.html',
  styleUrls: ['./broker-registration.component.css']
})
export class BrokerRegistrationComponent {
  @Output() closeModal: EventEmitter<void> = new EventEmitter<void>();
  registrationForm: FormGroup;
  registrationSuccess = false;

  constructor(private fb: FormBuilder, private router: Router) {
    this.registrationForm = this.fb.group({
      name: ['', Validators.required],
      email: [
        '',
        [Validators.required, Validators.email]
      ],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      // Process the form submission (e.g., call a service to save data)
      console.log('Registration Data:', this.registrationForm.value);
      this.registrationSuccess = true;
      alert('Registration successful!');
      this.router.navigate(['/login']);
      this.close();
    }
  }

  
  close() {
    this.closeModal.emit();
  }
}
