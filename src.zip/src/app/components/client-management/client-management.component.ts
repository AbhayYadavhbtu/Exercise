import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

interface Client {
  id: number;
  name: string;
  email: string;
  address: string;
}

@Component({
  selector: 'app-client-management',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterModule],
  templateUrl: './client-management.component.html',
  styleUrls: ['./client-management.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ClientManagementComponent implements OnInit {
  // Hardcoded client array
  clients: Client[] = [];
  
  // Pagination settings
  currentPage: number = 1;
  itemsPerPage: number = 6;
  totalPages: number = 1;
  
  // Form model for creating a new client
  newClient: Partial<Client> = {
    name: '',
    email: '',
    address: ''
  };

  // Modal: selected client for details view
  selectedClient: Client | null = null;

  ngOnInit(): void {
    // Sample data; optionally load from backend later
    this.clients = [
      { id: 1, name: 'Alice Johnson', email: 'alice@example.com', address: '123 Main St, City A' },
      { id: 2, name: 'Bob Smith', email: 'bob@example.com', address: '456 Oak St, City B' },
      { id: 3, name: 'Charlie Davis', email: 'charlie@example.com', address: '789 Pine St, City C' },
      { id: 4, name: 'Diana West', email: 'diana@example.com', address: '321 Elm St, City D' },
      { id: 5, name: 'Edward Black', email: 'edward@example.com', address: '654 Maple Ave, City E' },
      { id: 6, name: 'Fiona Grey', email: 'fiona@example.com', address: '987 Cedar Rd, City F' },
      { id: 7, name: 'George White', email: 'george@example.com', address: '147 Birch Ln, City G' },
      { id: 8, name: 'Hannah Green', email: 'hannah@example.com', address: '258 Walnut St, City H' }
    ];
    this.calculateTotalPages();
  }

  // Add a new client from the form
  addClient(): void {
    if (this.newClient.name && this.newClient.email && this.newClient.address) {
      const newId = this.clients.length > 0 ? Math.max(...this.clients.map(c => c.id)) + 1 : 1;
      const client: Client = {
        id: newId,
        name: this.newClient.name,
        email: this.newClient.email,
        address: this.newClient.address
      };
      this.clients.push(client);
      this.newClient = { name: '', email: '', address: '' };
      this.calculateTotalPages();
    } else {
      alert('Please fill out all fields');
    }
  }

  // Calculate total pages based on number of clients and itemsPerPage
  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.clients.length / this.itemsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
  }

  // Getter for paginated client list
  get paginatedClients(): Client[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.clients.slice(startIndex, startIndex + this.itemsPerPage);
  }

  // Pagination: Navigate to a given page
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  // Open modal popup to view client details
  viewClient(client: Client): void {
    this.selectedClient = client;
  }

  // Close modal popup
  closeModal(): void {
    this.selectedClient = null;
  }

  // Edit client - placeholder action
  editClient(client: Client): void {
    alert(`Edit client: ${client.name}`);
  }

  // Delete client after confirmation
  deleteClient(client: Client): void {
    if (confirm(`Are you sure you want to delete client: ${client.name}?`)) {
      this.clients = this.clients.filter(c => c.id !== client.id);
      if (this.selectedClient && this.selectedClient.id === client.id) {
        this.selectedClient = null;
      }
      this.calculateTotalPages();
    }
  }
}
