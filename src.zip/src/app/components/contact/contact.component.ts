import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ContactComponent {
  formData = {
    firstName: '',
    lastName: '',
    email: '',
    message: ''
  };

  onSubmit(): void {
    // Placeholder for form submission logic
    alert(`Thank you, ${this.formData.firstName}! We have received your message.`);
  }
}
